﻿namespace Ex05
{
    public enum eRoundState
    {
        Ongoing,
        Win,
        Draw
    }
}

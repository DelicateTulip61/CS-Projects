﻿namespace Ex05
{
    public enum eCell
    {
        Empty,
        X,
        O
    }
}
